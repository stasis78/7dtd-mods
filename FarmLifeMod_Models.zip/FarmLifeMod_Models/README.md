# Installation

FarmLifeMod_Models *requires* [FarmLifeMod](https://github.com/stasis78/7dtd-mods/tree/master/FarmLifeMod) or it won't do anything for you.

See install instructions [here](https://github.com/stasis78/7dtd-mods/tree/master/FarmLifeMod/README.md)

## About

This modlet is only made possible by **syn7572**'s very hard work! They have full credit for all their work on the following models:

- Pitch Fork
