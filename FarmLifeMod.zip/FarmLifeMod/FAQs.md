# FAQs

These are frequently asked questions.

## Where do I get seeds?

Thats a wonderful question and appreciate that you asked.

Seeds for Farm Life are found just life vanilla seeds. You can loot them and buy them from traders. Trash piles, cupboards, and sinks are great places to look for them.

Once you have enough of the fruit or vegetable, you can craft them. For trees you MUST loot them or buy them though.

## How dot pens work? I'm really confused!

I'm sorry for the confusion. Let me try to make it very simple.

To raise livestock you do the following.

- Craft a Pen
- Place the Pen on the ground (they do not stack on top of each other)
- Craft a "Pitch Fork"
- Make either "Cattle Feed" or "Chicken Feed" (depends on whether a pen or a coop)
- Equip the Pitch Fork and then "upgrade" the Empty Pen/Coop
- Wait for the critters to finish eating and growing
- Harvest with a Machete or Knife for best results

Hope that clears this up!
